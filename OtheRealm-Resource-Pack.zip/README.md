# OtheRealm-Resource-Pack
This is the git repo for the OtheRealm Season 2 Resource pack. We use custom-model-data, and this allows members to upload their textures when they want!


## Model List
The model_list.csv is a list of every custom model we have and its number. Update this for every new addition!

### Examples
The carved_pumpkin and iron_nugget have example models with a santa hat and a globe. Follow along or wait for the example video to get made!

### Link!
To add this server resource pack: in the server.properties set the resource pack to be:
https://github.com/vapor6701/OtheRealm-Resource-Pack/raw/main/OtheRealm-Resource-Pack.zip

